CASPIAN DARYN — Бастапқы сайт

1) index.html файлын браузерде ашып, сайтты көріңіз.
2) Мәтіндерді өзгерту үшін index.html файлын Notepad немесе VS Code арқылы ашыңыз.
3) [жақша ішіндегі] байланыс деректерін нақты ақпаратпен ауыстырыңыз.

Жариялау:
- GitHub аккаунт ашыңыз: https://github.com/
- Жаңа public repository жасаңыз (мысалы: caspiandaryn)
- index.html файлын жүктеңіз
- Settings -> Pages -> Deploy from a branch -> main -> /(root) -> Save
- GitHub сайт адресін береді.

Ескерту:
Бұл — дайын статикалық сайт файлы. Ол интернетке автоматты түрде жарияланбаған.
GitHub Pages субдомені Google Workspace for Education домен иелігін растауға жарамды деп кепілдік бермейді.
Google TXT жазбасы үшін DNS басқаруы бар, сізге тиесілі домен қажет.
